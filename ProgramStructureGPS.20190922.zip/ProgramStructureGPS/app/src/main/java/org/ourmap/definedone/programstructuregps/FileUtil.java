package org.ourmap.definedone.programstructuregps;

import java.io.File;
import java.io.IOException;

public class FileUtil {

    /**
     * 创建了父目录就可以直接写入数据到子文件
     */
    public static void createFileIfNotExist(String filename) {
        File file = new File(filename);
        File parentFile = file.getParentFile();
        if (parentFile == null) {
            return;
        }
        if (!parentFile.exists()) {
            parentFile.mkdirs();
        }
        if (!file.exists()) {
            try {
                file.createNewFile();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }
}
