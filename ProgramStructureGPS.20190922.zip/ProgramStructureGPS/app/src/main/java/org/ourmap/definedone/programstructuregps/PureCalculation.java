package org.ourmap.definedone.programstructuregps;

import android.location.Address;
import android.location.Location;
import android.text.TextUtils;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;

/**
 * 单纯计算
 */

public class PureCalculation {

    public static LocationBean locationToBean(Location location) {
        LocationBean locationBean = new LocationBean();
        locationBean.setProvider(location.getProvider());
        locationBean.setLatitude(location.getLatitude());
        locationBean.setLongitude(location.getLongitude());
        locationBean.setAltitude(location.getAltitude());
        locationBean.setTime(location.getTime());
        return locationBean;
    }

    public static String locationBeanListToString (ArrayList<LocationBean> mLocationBeanList) {
        StringBuilder sb = new StringBuilder(); // yyyy-MM-dd
        SimpleDateFormat DATETIME_FORMAT = new SimpleDateFormat("HH:mm:ss", Locale.CHINA);
        for(LocationBean item: mLocationBeanList) {
            String time = DATETIME_FORMAT.format(new Date(item.getTime()));
            if (item.getSituation() != null) {
                sb.append(time).append("　").append("[").append(item.getSituation()).append("]").append("\n");
            } else {
                sb.append(time).append("　").append("[")
                        .append(String.format("%.9f", item.getLongitude())).append(",　")
                        .append(String.format("%.9f", item.getLatitude())).append("]").append("\n");
            }
        }
        sb.deleteCharAt(sb.length() - 1);
        return sb.toString();
    }

    public static AddressBean addressToAddressBean(Address address) {
        AddressBean bean = new AddressBean();
        bean.setFeatureName(TextUtils.isEmpty(address.getFeatureName()) ? null : address.getFeatureName());
        List<String> mAddressLines = new ArrayList<>();
        for(int index=0; index <= address.getMaxAddressLineIndex(); index++) {
            mAddressLines.add(address.getAddressLine(index));
        }
        bean.setAddressLines(mAddressLines);
        bean.setAdminArea(TextUtils.isEmpty(address.getAdminArea()) ? null : address.getAdminArea());
        bean.setSubAdminArea(TextUtils.isEmpty(address.getSubAdminArea()) ? null : address.getSubAdminArea());
        bean.setLocality(TextUtils.isEmpty(address.getLocality()) ? null : address.getLocality());
        bean.setSubLocality(TextUtils.isEmpty(address.getSubLocality()) ? null : address.getSubLocality());
        bean.setThoroughfare(TextUtils.isEmpty(address.getThoroughfare()) ? null : address.getThoroughfare());
        bean.setSubThoroughfare(TextUtils.isEmpty(address.getSubThoroughfare()) ? null : address.getSubThoroughfare());
        bean.setPremises(TextUtils.isEmpty(address.getPremises()) ? null : address.getPremises());
        bean.setPostalCode(TextUtils.isEmpty(address.getPostalCode()) ? null : address.getPostalCode());
        bean.setCountryCode(TextUtils.isEmpty(address.getCountryCode()) ? null : address.getCountryCode());
        bean.setCountryName(TextUtils.isEmpty(address.getCountryName()) ? null : address.getCountryName());
        return bean;
    }
}
