package org.ourmap.definedone.programstructuregps;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;

public abstract class BaseActivity<T extends BaseExternalRelations> extends AppCompatActivity {

    protected T mExternalRelations;
    private ActivityLifecycleCallback mLifecycleCallback;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(getLayoutResID());
        mExternalRelations = createExternalRelations();
        findViewAndSetListener();
        mLifecycleCallback = mExternalRelations.getActivityLifecycleCallback();
        mLifecycleCallback.onModulesCreated();
    }

    protected abstract int getLayoutResID();
    protected abstract T createExternalRelations();
    protected abstract void findViewAndSetListener();

    @Override
    protected void onResume() {
        super.onResume();
        if (mLifecycleCallback != null) {
            mLifecycleCallback.onResume();
        }
    }

    @Override
    protected void onPause() {
        if (mLifecycleCallback != null) {
            mLifecycleCallback.onPause();
        }
        super.onPause();
    }

    @Override
    protected void onDestroy() {
        if (mLifecycleCallback != null) {
            mLifecycleCallback.onDestroy();
        }
        super.onDestroy();
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (mLifecycleCallback != null) {
            mLifecycleCallback.onRequestPermissionsResult(requestCode, permissions, grantResults);
        }
    }
}
