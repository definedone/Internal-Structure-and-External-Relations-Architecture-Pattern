package org.ourmap.definedone.programstructuregps;

import android.util.TypedValue;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

/**
 * 显示模块
 */
public class MainActivity extends BaseActivity<ExternalRelations> {

    private TextView vTextLocationResult;
    private TextView vTextLocationAddress;
    private TextView vTextGpsStatus;
    private TextView vTextAddSituation;
    private EditText vEditSituation;
    private TextView vTextTextSize;
    private float mTextSize;

    @Override
    protected int getLayoutResID() {
        return R.layout.activity_main;
    }

    @Override
    protected ExternalRelations createExternalRelations() {
        return new ExternalRelations(this);
    }

    @Override
    protected void findViewAndSetListener() {
        findViewById();
        setListener();
    }

    private void findViewById() {
        vTextLocationResult = (TextView)findViewById(R.id.vTextLocationResult);
        vTextLocationAddress = (TextView)findViewById(R.id.vTextLocationAddress);
        vTextGpsStatus = (TextView)findViewById(R.id.vTextGpsStatus);
        vTextAddSituation = (TextView)findViewById(R.id.vTextAddSituation);
        vEditSituation = (EditText)findViewById(R.id.vEditSituation);
        vTextTextSize = (TextView)findViewById(R.id.vTextTextSize);
    }

    private void setListener() {
        vTextAddSituation.setOnClickListener(mExternalRelations.getOnAddSituationClickListener());
        final float minSize = 12;
        mTextSize = minSize;
        vTextTextSize.setOnClickListener((v)->{
            mTextSize += 2;
            mTextSize = minSize + (mTextSize - minSize) % 8;
            vTextLocationResult.setTextSize(TypedValue.COMPLEX_UNIT_SP, mTextSize);
        });
    }

    public void setGpsStatus(String status) {
        vTextGpsStatus.setText(status);
    }

    public void setLocationResult(String locationResult) {
        vTextLocationResult.setText(locationResult);
    }

    public void setLocationAddress(String locationAddress) {
        vTextLocationAddress.setText(locationAddress);
    }

    public String getSituation() {
        String result = vEditSituation.getText().toString();
        vEditSituation.setText("");
        return result;
    }

    public void showToast(String message) {
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show();
    }

}
