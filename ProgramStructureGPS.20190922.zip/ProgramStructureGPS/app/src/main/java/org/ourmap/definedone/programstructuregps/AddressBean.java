package org.ourmap.definedone.programstructuregps;

import java.util.HashMap;
import java.util.List;

public class AddressBean {

    private String mFeatureName;
    private List<String> mAddressLines;
    private String mAdminArea;
    private String mSubAdminArea;
    private String mLocality;
    private String mSubLocality;
    private String mThoroughfare;
    private String mSubThoroughfare;
    private String mPremises;
    private String mPostalCode;
    private String mCountryCode;
    private String mCountryName;

    public String getFeatureName() {
        return mFeatureName;
    }

    public void setFeatureName(String mFeatureName) {
        this.mFeatureName = mFeatureName;
    }

    public List<String> getAddressLines() {
        return mAddressLines;
    }

    public void setAddressLines(List<String> mAddressLines) {
        this.mAddressLines = mAddressLines;
    }

    public String getAdminArea() {
        return mAdminArea;
    }

    public void setAdminArea(String mAdminArea) {
        this.mAdminArea = mAdminArea;
    }

    public String getSubAdminArea() {
        return mSubAdminArea;
    }

    public void setSubAdminArea(String mSubAdminArea) {
        this.mSubAdminArea = mSubAdminArea;
    }

    public String getLocality() {
        return mLocality;
    }

    public void setLocality(String mLocality) {
        this.mLocality = mLocality;
    }

    public String getSubLocality() {
        return mSubLocality;
    }

    public void setSubLocality(String mSubLocality) {
        this.mSubLocality = mSubLocality;
    }

    public String getThoroughfare() {
        return mThoroughfare;
    }

    public void setThoroughfare(String mThoroughfare) {
        this.mThoroughfare = mThoroughfare;
    }

    public String getSubThoroughfare() {
        return mSubThoroughfare;
    }

    public void setSubThoroughfare(String mSubThoroughfare) {
        this.mSubThoroughfare = mSubThoroughfare;
    }

    public String getPremises() {
        return mPremises;
    }

    public void setPremises(String mPremises) {
        this.mPremises = mPremises;
    }

    public String getPostalCode() {
        return mPostalCode;
    }

    public void setPostalCode(String mPostalCode) {
        this.mPostalCode = mPostalCode;
    }

    public String getCountryCode() {
        return mCountryCode;
    }

    public void setCountryCode(String mCountryCode) {
        this.mCountryCode = mCountryCode;
    }

    public String getCountryName() {
        return mCountryName;
    }

    public void setCountryName(String mCountryName) {
        this.mCountryName = mCountryName;
    }
}
