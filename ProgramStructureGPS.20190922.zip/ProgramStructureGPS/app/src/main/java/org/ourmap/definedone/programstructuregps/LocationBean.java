package org.ourmap.definedone.programstructuregps;

/**
 * Created by Administrator on 2019-8-31.
 */

public class LocationBean {

//        Log.e("xyh", "定位方式：" + location.getProvider());
//        Log.e("xyh", "纬度：" + location.getLatitude());
//        Log.e("xyh", "经度：" + location.getLongitude());
//        Log.e("xyh", "海拔：" + location.getAltitude());
//        Log.e("xyh", "时间：" + location.getTime());

    private String provider;
    private double latitude;
    private double longitude;
    private double altitude;
    private long time;
    private String situation;
    private AddressBean address;

    public String getProvider() {
        return provider;
    }

    public void setProvider(String provider) {
        this.provider = provider;
    }

    public double getLatitude() {
        return latitude;
    }

    public void setLatitude(double latitude) {
        this.latitude = latitude;
    }

    public double getLongitude() {
        return longitude;
    }

    public void setLongitude(double longitude) {
        this.longitude = longitude;
    }

    public double getAltitude() {
        return altitude;
    }

    public void setAltitude(double altitude) {
        this.altitude = altitude;
    }

    public long getTime() {
        return time;
    }

    public void setTime(long time) {
        this.time = time;
    }

    public String getSituation() {
        return situation;
    }

    public void setSituation(String situation) {
        this.situation = situation;
    }

    public AddressBean getAddress() {
        return address;
    }

    public void setAddress(AddressBean address) {
        this.address = address;
    }
}
