package org.ourmap.definedone.programstructuregps;

public class BaseExternalRelations {

    public ActivityLifecycleCallback getActivityLifecycleCallback() {
        return new ActivityLifecycleCallback(){};
    }
}
