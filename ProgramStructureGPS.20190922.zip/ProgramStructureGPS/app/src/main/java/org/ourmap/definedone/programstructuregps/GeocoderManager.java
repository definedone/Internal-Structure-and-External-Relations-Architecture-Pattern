package org.ourmap.definedone.programstructuregps;

import android.content.Context;
import android.location.Address;
import android.location.Geocoder;

import java.io.IOException;
import java.util.List;
import java.util.Locale;

/**
 * Created by Administrator on 2019-8-30.
 */

public class GeocoderManager {

    private Geocoder mGeocoder;

    public GeocoderManager(Context context) {
        mGeocoder = new Geocoder(context, Locale.getDefault());
    }

    public Address getAddress(double latitude, double longitude) {
        try {
            List<Address> addresses = mGeocoder.getFromLocation(latitude, longitude, 1);
            if (addresses.size() > 0) {
                return addresses.get(0);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        return null;
    }

}
