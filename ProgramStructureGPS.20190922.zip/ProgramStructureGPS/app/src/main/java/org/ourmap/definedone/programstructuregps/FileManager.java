package org.ourmap.definedone.programstructuregps;

import java.io.BufferedWriter;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.io.UnsupportedEncodingException;

/**
 * 文件模块
 */

public class FileManager {

    private String mPath;
    private BufferedWriter mWriter;

    public FileManager(String path) {
        mPath = path;
    }

    public void open() {
        try {
            FileUtil.createFileIfNotExist(mPath);
            mWriter = new BufferedWriter(new OutputStreamWriter(
                    new FileOutputStream(mPath, true), "UTF-8"));
        } catch (UnsupportedEncodingException e) {
            e.printStackTrace();
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }
    }

    public void write(String text) {
        try {
            mWriter.write(text);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void close() {
        try {
            mWriter.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

}
