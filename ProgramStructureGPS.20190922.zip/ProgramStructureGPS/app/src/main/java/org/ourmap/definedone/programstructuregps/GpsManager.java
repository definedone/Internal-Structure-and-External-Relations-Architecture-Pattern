package org.ourmap.definedone.programstructuregps;

import android.content.Context;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;

/**
 * GPS模块
 */

public class GpsManager {

    private Context mContext;
    private LocationManager mLocationManager;
    private LocationListener mLocationListener;
    private ExternalRelations mExternalRelations;

    public GpsManager(Context context, ExternalRelations externalRelations) {
        mContext = context;
        mExternalRelations = externalRelations;
        mLocationManager = (LocationManager) context.getSystemService(Context.LOCATION_SERVICE);
        mLocationListener = mExternalRelations.getLocationListener();
    }

    /**
     * GPS功能是否已开启
     */
    public boolean isGpsProviderEnabled() {
        return mLocationManager.isProviderEnabled(LocationManager.GPS_PROVIDER);
    }

    /**
     * 先于requestLocationUpdates()执行
     */
    public Location getLastKnownLocation() {
        return mLocationManager.getLastKnownLocation(LocationManager.GPS_PROVIDER);
    }

    public void requestLocationUpdates() {
        removeUpdates();
        // minTime minimum time interval between location updates, in milliseconds
        // minDistance minimum distance between location updates, in meters
        mLocationManager.requestLocationUpdates(LocationManager.GPS_PROVIDER, 1000, 1,
                mLocationListener);
    }

    public void removeUpdates() {
        if (mLocationListener != null) {
            mLocationManager.removeUpdates(mLocationListener);
        }
    }
}
