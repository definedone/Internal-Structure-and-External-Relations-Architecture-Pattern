package org.ourmap.definedone.programstructuregps;

import android.Manifest;
import android.location.Address;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationProvider;
import android.os.Bundle;
import android.os.Environment;
import android.support.v4.app.ActivityCompat;
import android.view.View;

import com.google.gson.Gson;

import org.ourmap.definedone.programstructuregps.permission.PermissionUtils;

import java.io.File;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Locale;

/**
 * 外部关系模块
 */
public class ExternalRelations extends BaseExternalRelations {

    private static final int REQUEST_LOCATION_PERMISSIONS = 8;
    public static final String[] LOCATION_PERMISSIONS = {
            Manifest.permission.ACCESS_FINE_LOCATION,
            Manifest.permission.ACCESS_COARSE_LOCATION
    };
    private static final int REQUEST_STORAGE_PERMISSIONS = 9;
    public static final String[] STORAGE_PERMISSIONS = {
            Manifest.permission.READ_EXTERNAL_STORAGE,
            Manifest.permission.WRITE_EXTERNAL_STORAGE
    };

    private MainActivity mMainActivity;
    private GpsManager mGpsManager;
    private GeocoderManager mGeocoderManager;
    private FileManager mFileManager;
    private ArrayList<LocationBean> mLocationBeanList = new ArrayList<>();

    public ExternalRelations(MainActivity mainActivity) {
        mMainActivity = mainActivity;
        mGpsManager = new GpsManager(mainActivity.getApplicationContext(), this);
        mGeocoderManager = new GeocoderManager(mainActivity.getApplicationContext());
        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd_HH-mm-ss", Locale.CHINA);
        String timestamp = dateFormat.format(new Date(System.currentTimeMillis()));
        String filename = Environment.getExternalStorageDirectory().getAbsolutePath()
                + File.separator + "program_structure_gps"
                + File.separator + "gps_" + timestamp + ".txt";
        mFileManager = new FileManager(filename);
    }

    @Override
    public ActivityLifecycleCallback getActivityLifecycleCallback() {
        return new ActivityLifecycleCallback() {
            @Override
            public void onModulesCreated() { // 当各个模块都创建完成后，所执行的
                requestStoragePermissionsOrNextStep();
            }
            @Override
            public void onDestroy() {
                mGpsManager.removeUpdates();
                mFileManager.close();
            }
            @Override
            public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
                if (requestCode == REQUEST_LOCATION_PERMISSIONS) {
                    if (PermissionUtils.getTargetSdkVersion(mMainActivity) < 23
                            && !PermissionUtils.hasSelfPermissions(mMainActivity, LOCATION_PERMISSIONS)) {
                        showRequestPermissionsDenied();
                    } else {
                        if (PermissionUtils.verifyPermissions(grantResults)) {
                            mGpsManager.requestLocationUpdates();
                        } else {
                            showRequestPermissionsDenied();
                        }
                    }
                } else if (requestCode == REQUEST_STORAGE_PERMISSIONS) {
                    if (PermissionUtils.getTargetSdkVersion(mMainActivity) < 23
                            && !PermissionUtils.hasSelfPermissions(mMainActivity, STORAGE_PERMISSIONS)) {
                        showRequestPermissionsDenied();
                    } else {
                        if (PermissionUtils.verifyPermissions(grantResults)) {
                            afterGetStoragePermissions();
                        } else {
                            showRequestPermissionsDenied();
                        }
                    }
                }
            }
            private void showRequestPermissionsDenied() {
                mMainActivity.showToast("拒绝权限将无法使用");
            }
        };
    }

    private void requestStoragePermissionsOrNextStep() {
        if (PermissionUtils.hasSelfPermissions(mMainActivity, STORAGE_PERMISSIONS)) {
            afterGetStoragePermissions();
        } else {
            ActivityCompat.requestPermissions(mMainActivity, STORAGE_PERMISSIONS, REQUEST_STORAGE_PERMISSIONS);
        }
    }

    private void afterGetStoragePermissions() {
        mFileManager.open();
        mFileManager.write("\n\n##\n");
        if (!mGpsManager.isGpsProviderEnabled()) {
            mMainActivity.showToast("GPS功能还未开启！");
        }
        requestLocationPermissionsOrLocationUpdates();
    }

    private void requestLocationPermissionsOrLocationUpdates() {
        if (PermissionUtils.hasSelfPermissions(mMainActivity, LOCATION_PERMISSIONS)) {
            mGpsManager.requestLocationUpdates();
        } else {
            ActivityCompat.requestPermissions(mMainActivity, LOCATION_PERMISSIONS, REQUEST_LOCATION_PERMISSIONS);
        }
    }

    public View.OnClickListener getOnAddSituationClickListener() {
        return (v) -> {
            LocationBean locationBean = new LocationBean();
            locationBean.setSituation(mMainActivity.getSituation());
            locationBean.setTime(System.currentTimeMillis());
            addLocationBeanAndKeepSize(locationBean);
        };
    }

    private void addLocationBeanAndKeepSize(LocationBean locationBean) {
        mLocationBeanList.add(locationBean);
        if (mLocationBeanList.size() > 8) {
            mLocationBeanList.remove(0);
        }
        mMainActivity.setLocationResult(PureCalculation.locationBeanListToString(mLocationBeanList));
    }

    public LocationListener getLocationListener() {
        return new LocationListener() {
            @Override
            public void onLocationChanged(Location location) {
                if (location == null) {
                    return;
                }
                //位置信息变化时触发
                LocationBean locationBean = PureCalculation.locationToBean(location);
                addLocationBeanAndKeepSize(locationBean);
                Address address = mGeocoderManager.getAddress(location.getLatitude(), location.getLongitude());
                if (address != null) {
                    AddressBean addressBean = PureCalculation.addressToAddressBean(address);
                    locationBean.setAddress(addressBean);
                    mMainActivity.setLocationAddress(new Gson().toJson(addressBean));
                }
                mFileManager.write(new Gson().toJson(locationBean));
                mFileManager.write("\n");
            }

            @Override
            public void onStatusChanged(String provider, int status, Bundle extras) {
                //GPS状态变化时触发
                switch (status) {
                    case LocationProvider.AVAILABLE:
                        mMainActivity.setGpsStatus("可用");
                        break;
                    case LocationProvider.OUT_OF_SERVICE:
                        mMainActivity.setGpsStatus("不在服务范围");
                        break;
                    case LocationProvider.TEMPORARILY_UNAVAILABLE:
                        mMainActivity.setGpsStatus("暂时不可用");
                        break;
                }
            }

            @Override
            public void onProviderEnabled(String provider) {
                //GPS开启时触发
                mMainActivity.showToast("GPS功能已经开启！");
                requestLocationPermissionsOrLocationUpdates();
            }

            @Override
            public void onProviderDisabled(String provider) {
                //GPS禁用时触发
                mMainActivity.showToast("GPS功能已经关闭！");
            }
        };
    }
}
