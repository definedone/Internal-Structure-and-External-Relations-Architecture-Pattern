package org.ourmap.definedone.programstructuregps;

public class ActivityLifecycleCallback {

    public void onModulesCreated() {
    }

    public void onResume() {
    }

    public void onPause() {
    }

    public void onDestroy() {
    }

    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
    }
}
